# Calculator Pro Plus

A class-based calculator CLI application built using Python.

## Features
- Basic arithmetic operations
- History tracking
- OOP implementation
- Exception handling

## Run
python calculator_pro.py
