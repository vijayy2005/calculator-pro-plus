
class Calculator:
    def __init__(self):
        self.history = []

    def calculate(self, choice, a, b):
        if choice == "1":
            result = a + b
            op = "+"
        elif choice == "2":
            result = a - b
            op = "-"
        elif choice == "3":
            result = a * b
            op = "*"
        else:
            result = "Cannot divide by zero" if b == 0 else a / b
            op = "/"

        self.history.append(f"{a} {op} {b} = {result}")
        return result

    def show_history(self):
        if not self.history:
            print("No history available.")
        else:
            for item in self.history:
                print(item)

calc = Calculator()

while True:
    print("\nCALCULATOR PRO PLUS")
    print("1.Add 2.Subtract 3.Multiply 4.Divide 5.History 6.Exit")
    choice = input("Choice: ")

    if choice == "6":
        break

    if choice == "5":
        calc.show_history()
        continue

    try:
        a = float(input("First number: "))
        b = float(input("Second number: "))
        print("Result:", calc.calculate(choice, a, b))
    except ValueError:
        print("Enter valid numbers.")
